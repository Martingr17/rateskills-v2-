# app/main.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, jsonify
from flask_login import login_required, current_user
from .models import User, Skill, SkillAssessment, Department, AssessmentHistory
from . import db
from .forms import AssessForm, ManagerAdjustForm
import io, csv
from datetime import datetime

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))

@main_bp.route('/dashboard')
@login_required
def dashboard():
    skills = Skill.query.order_by(Skill.category, Skill.name).all()
    user_assessments = {a.skill_id: a for a in current_user.assessments}
    return render_template('dashboard.html', skills=skills, user_assessments=user_assessments)

@main_bp.route('/profile/<int:user_id>')
@login_required
def profile(user_id):
    user = User.query.get_or_404(user_id)
    labels = []
    self_scores = []
    manager_scores = []
    for a in user.assessments:
        labels.append(a.skill.name)
        self_scores.append(a.self_score or 0)
        manager_scores.append(a.manager_score or 0)
    return render_template('profile.html', profile_user=user, labels=labels, self_scores=self_scores, manager_scores=manager_scores)

@main_bp.route('/assess', methods=['POST'])
@login_required
def assess():
    form = AssessForm()
    if form.validate_on_submit():
        skill_id = form.skill_id.data
        score = form.score.data
        assessment = SkillAssessment.query.filter_by(user_id=current_user.id, skill_id=skill_id).first()
        if not assessment:
            assessment = SkillAssessment(user_id=current_user.id, skill_id=skill_id, self_score=score)
            db.session.add(assessment)
            db.session.commit()
            flash('Оценка создана','success')
        else:
            old = assessment.self_score or 0
            if old != score:
                ah = AssessmentHistory(assessment=assessment, field='self_score', old_score=old, new_score=score, changed_by=current_user.id)
                db.session.add(ah)
            assessment.self_score = score
            assessment.assessed_at = datetime.utcnow()
            db.session.commit()
            flash('Оценка обновлена','success')
    else:
        flash('Ошибка в форме','danger')
    return redirect(url_for('main.dashboard'))

@main_bp.route('/manager/department')
@login_required
def manager_department():
    if current_user.role != 'manager':
        flash('Недостаточно прав','danger')
        return redirect(url_for('main.dashboard'))
    dept = current_user.department
    employees = User.query.filter_by(department_id=dept.id).all()
    return render_template('manager.html', employees=employees, department=dept)

@main_bp.route('/manager/adjust', methods=['POST'])
@login_required
def manager_adjust():
    if current_user.role != 'manager':
        flash('Недостаточно прав','danger')
        return redirect(url_for('main.dashboard'))
    form = ManagerAdjustForm()
    if form.validate_on_submit():
        assessment_id = form.assessment_id.data
        new_score = form.manager_score.data
        assessment = SkillAssessment.query.get_or_404(assessment_id)
        # only allow if manager manages that employee or admin
        if not current_user.is_manager_of(assessment.user) and current_user.role != 'admin':
            flash('Вы не можете менять оценки этого сотрудника','danger')
            return redirect(url_for('main.manager_department'))
        old = assessment.manager_score or 0
        if old != new_score:
            ah = AssessmentHistory(assessment=assessment, field='manager_score', old_score=old, new_score=new_score, changed_by=current_user.id)
            db.session.add(ah)
        assessment.manager_score = new_score
        db.session.commit()
        flash('Оценка менеджера обновлена','success')
    else:
        flash('Некорректная форма','danger')
    return redirect(url_for('main.manager_department'))

@main_bp.route('/search')
@login_required
def search():
    q = request.args.get('q','').strip()
    minscore = int(request.args.get('min', '4'))
    results = []
    if q:
        skill_q = Skill.query.filter(Skill.name.ilike(f'%{q}%')).all()
        for skill in skill_q:
            assessments = SkillAssessment.query.filter(SkillAssessment.skill==skill, SkillAssessment.self_score >= minscore).all()
            results.extend(assessments)
    return render_template('search.html', results=results, q=q, minscore=minscore)

@main_bp.route('/compare')
@login_required
def compare():
    a = request.args.get('a', type=int)
    b = request.args.get('b', type=int)
    user_a = User.query.get(a) if a else None
    user_b = User.query.get(b) if b else None
    labels = []
    data_a = []
    data_b = []
    if user_a or user_b:
        skills_set = {}
        if user_a:
            for asmt in user_a.assessments:
                skills_set[asmt.skill.name] = True
        if user_b:
            for asmt in user_b.assessments:
                skills_set[asmt.skill.name] = True
        labels = sorted(skills_set.keys())
        def scores_for(user):
            mapping = {a.skill.name: (a.self_score or 0) for a in (user.assessments if user else [])}
            return [mapping.get(l,0) for l in labels]
        data_a = scores_for(user_a)
        data_b = scores_for(user_b)
    return render_template('compare.html', user_a=user_a, user_b=user_b, labels=labels, data_a=data_a, data_b=data_b)

@main_bp.route('/history/<int:assessment_id>')
@login_required
def history(assessment_id):
    assessment = SkillAssessment.query.get_or_404(assessment_id)
    allowed = (current_user.id == assessment.user_id) or current_user.role in ('hr','admin') or current_user.is_manager_of(assessment.user)
    if not allowed:
        flash('Недостаточно прав','danger')
        return redirect(url_for('main.dashboard'))
    return render_template('history.html', assessment=assessment)

@main_bp.route('/export/csv')
@login_required
def export_csv():
    if current_user.role not in ('hr','admin','manager'):
        flash('Недостаточно прав','danger')
        return redirect(url_for('main.dashboard'))
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['user_id','user','department','skill','self_score','manager_score','assessed_at'])
    for a in SkillAssessment.query.join(User).join(Skill).all():
        cw.writerow([a.user_id, a.user.full_name or a.user.login, a.user.department.name if a.user.department else '', a.skill.name, a.self_score, a.manager_score, a.assessed_at])
    mem = io.BytesIO()
    mem.write(si.getvalue().encode('utf-8'))
    mem.seek(0)
    return send_file(mem, mimetype='text/csv', download_name='assessments.csv')

@main_bp.route('/api/user/<int:user_id>/assessments')
@login_required
def user_assessments_api(user_id):
    user = User.query.get_or_404(user_id)
    data = []
    for a in user.assessments:
        data.append({
            'skill': a.skill.name,
            'self_score': a.self_score,
            'manager_score': a.manager_score
        })
    return jsonify({'user': user.login, 'assessments': data})
