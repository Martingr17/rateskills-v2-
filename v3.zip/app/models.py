# app/models.py
from . import db, login_manager
from flask_login import UserMixin
from datetime import datetime

class Department(db.Model):
    tablename = 'department'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False, unique=True)
    manager_id = db.Column(db.Integer, db.ForeignKey('"user".id'), nullable=True)

    users = db.relationship('User', back_populates='department', cascade='all, delete-orphan')

class User(UserMixin, db.Model):
    # В коде и в логе у вас таблица называется "user" (в кавычках). Оставляем так, чтобы совпадало.
    tablename = 'user'
    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.String(128), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(64), default='user')
    full_name = db.Column(db.String(256))
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    department = db.relationship('Department', back_populates='users')
    assessments = db.relationship('SkillAssessment', back_populates='user', cascade='all, delete-orphan')

    def check_password(self, password):
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(user_id):
    try:
        return User.query.get(int(user_id))
    except Exception:
        return None

class Skill(db.Model):
    tablename = 'skill'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, unique=True)
    category = db.Column(db.String(100))
    description = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    assessments = db.relationship('SkillAssessment', back_populates='skill', cascade='all, delete-orphan')

class SkillAssessment(db.Model):
    tablename = 'skill_assessment'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('"user".id'), nullable=False)
    skill_id = db.Column(db.Integer, db.ForeignKey('skill.id'), nullable=False)
    self_score = db.Column(db.Integer)
    manager_score = db.Column(db.Integer)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', back_populates='assessments')
    skill = db.relationship('Skill', back_populates='assessments')
    history = db.relationship('AssessmentHistory', back_populates='assessment', cascade='all, delete-orphan', order_by="desc(AssessmentHistory.changed_at)")

class AssessmentHistory(db.Model):
    tablename = 'assessment_history'
    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey('skill_assessment.id'), nullable=False)
    field = db.Column(db.String(32))  # e.g. 'self_score' or 'manager_score'
    old_score = db.Column(db.Integer)
    new_score = db.Column(db.Integer)
    changed_by = db.Column(db.Integer, db.ForeignKey('"user".id'))
    changed_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessment = db.relationship('SkillAssessment', back_populates='history')
