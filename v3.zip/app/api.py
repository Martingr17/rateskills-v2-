# app/api.py
from flask import Blueprint, jsonify, request
from flask_login import login_required
from .models import Skill
from . import db

api_bp = Blueprint('api', __name__)

@api_bp.route('/skills')
@login_required
def list_skills():
    skills = Skill.query.all()
    return jsonify([{'id':s.id,'name':s.name,'category':s.category} for s in skills])

@api_bp.route('/search')
@login_required
def api_search():
    q = request.args.get('q','')
    if not q:
        return jsonify({'error':'q required'}), 400
    sk = Skill.query.filter(Skill.name.ilike(f'%{q}%')).all()
    data=[]
    for s in sk:
        data.append({'id':s.id,'name':s.name,'category':s.category})
    return jsonify(data)
