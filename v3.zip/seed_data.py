# seed_data.py
"""
Seed script: создает схему и базовые записи для dev окружения.
Запуск: python seed_data.py
"""
from sqlalchemy import create_engine, text
from werkzeug.security import generate_password_hash
import os

DATABASE_URI = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@db:5432/skilldb')
engine = create_engine(DATABASE_URI, echo=False, future=True)

with engine.begin() as conn:
    print("Dropping existing tables (if any)...")
    # Удаляем в правильном порядке, чтобы FK не мешали
    conn.execute(text('DROP TABLE IF EXISTS assessment_history CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS skill_assessment CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS skill CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS "user" CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS department CASCADE'))

    print("Creating tables...")
    conn.execute(text('''
        CREATE TABLE department (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            manager_id INTEGER
        );
    '''))
    conn.execute(text('''
        CREATE TABLE "user" (
            id SERIAL PRIMARY KEY,
            login VARCHAR(128) NOT NULL UNIQUE,
            password_hash VARCHAR(256) NOT NULL,
            role VARCHAR(64) DEFAULT 'user',
            full_name VARCHAR(256),
            department_id INTEGER,
            created_at TIMESTAMPTZ DEFAULT now(),
            updated_at TIMESTAMPTZ DEFAULT now()
        );
    '''))
    conn.execute(text('''
        CREATE TABLE skill (
            id SERIAL PRIMARY KEY,
            name VARCHAR(150) NOT NULL UNIQUE,
            category VARCHAR(100),
            description TEXT,
            created_at TIMESTAMPTZ DEFAULT now(),
            updated_at TIMESTAMPTZ DEFAULT now()
        );
    '''))
    conn.execute(text('''
        CREATE TABLE skill_assessment (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL,
            skill_id INTEGER NOT NULL,
            self_score INTEGER,
            manager_score INTEGER,
            updated_at TIMESTAMPTZ DEFAULT now()
        );
    '''))
    conn.execute(text('''
        CREATE TABLE assessment_history (
            id SERIAL PRIMARY KEY,
            assessment_id INTEGER NOT NULL,
            field VARCHAR(32),
            old_score INTEGER,
            new_score INTEGER,
            changed_by INTEGER,
            changed_at TIMESTAMPTZ DEFAULT now()
        );
    '''))

    print("Adding constraints/foreign keys...")
    conn.execute(text('ALTER TABLE department ADD CONSTRAINT fk_department_manager FOREIGN KEY (manager_id) REFERENCES "user"(id)'))
    conn.execute(text('ALTER TABLE "user" ADD CONSTRAINT fk_user_department FOREIGN KEY (department_id) REFERENCES department(id)'))
    conn.execute(text('ALTER TABLE skill_assessment ADD CONSTRAINT fk_assessment_user FOREIGN KEY (user_id) REFERENCES "user"(id)'))
    conn.execute(text('ALTER TABLE skill_assessment ADD CONSTRAINT fk_assessment_skill FOREIGN KEY (skill_id) REFERENCES skill(id)'))
    conn.execute(text('ALTER TABLE assessment_history ADD CONSTRAINT fk_history_assessment FOREIGN KEY (assessment_id) REFERENCES skill_assessment(id)'))
    conn.execute(text('ALTER TABLE assessment_history ADD CONSTRAINT fk_history_changed_by FOREIGN KEY (changed_by) REFERENCES "user"(id)'))

    print("Inserting seed data...")
    # create sample departments
    conn.execute(text("INSERT INTO department (name) VALUES ('Engineering'), ('HR'), ('Sales')"))
    # create users
    users = [
        ('alice', 'password', 'admin', 'Alice Admin'),
        ('bob', 'password', 'hr', 'Bob HR'),
        ('carol', 'password', 'user', 'Carol Dev'),
    ]
    for login, pwd, role, full in users:
        pw_hash = generate_password_hash(pwd)
        conn.execute(text("INSERT INTO \"user\" (login, password_hash, role, full_name) VALUES (:login, :pw, :role, :full)"),
                     {"login": login, "pw": pw_hash, "role": role, "full": full})
    # sample skills
    conn.execute(text("INSERT INTO skill (name, category, description) VALUES "
                      "('Python','Engineering','Python programming'),"
                      "('SQL','Engineering','SQL and databases'),"
                      "('Recruiting','HR','Hiring processes')"))
    print("Seed complete. Users: alice/password, bob/password, carol/password")
