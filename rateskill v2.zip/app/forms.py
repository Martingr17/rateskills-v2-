# app/forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Length, NumberRange, Optional, Email

class LoginForm(FlaskForm):
    login = StringField('Логин', validators=[DataRequired(), Length(min=2, max=128)])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')

class SkillForm(FlaskForm):
    name = StringField('Название', validators=[DataRequired(), Length(max=128)])
    category = StringField('Категория', validators=[Optional(), Length(max=64)])
    description = TextAreaField('Описание', validators=[Optional(), Length(max=2000)])
    submit = SubmitField('Сохранить')

class AssessForm(FlaskForm):
    skill_id = IntegerField('skill_id', validators=[DataRequired()])
    score = IntegerField('Оценка', validators=[DataRequired(), NumberRange(min=1, max=5)])
    submit = SubmitField('Сохранить')

class ManagerAdjustForm(FlaskForm):
    assessment_id = IntegerField('assessment_id', validators=[DataRequired()])
    manager_score = IntegerField('Оценка менеджера', validators=[DataRequired(), NumberRange(min=1, max=5)])
    submit = SubmitField('Применить')

class UserCreateForm(FlaskForm):
    login = StringField('Логин', validators=[DataRequired()])
    full_name = StringField('Имя', validators=[Optional()])
    email = StringField('Email', validators=[Optional(), Email()])
    role = SelectField('Роль', choices=[('employee','Сотрудник'),('manager','Руководитель'),('hr','HR'),('admin','Админ')])
    department_id = IntegerField('department_id', validators=[Optional()])
    submit = SubmitField('Создать')
