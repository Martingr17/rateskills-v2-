# app/hr.py
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from .models import Skill, User, Department
from . import db
from .forms import SkillForm, UserCreateForm
from werkzeug.security import generate_password_hash

hr_bp = Blueprint('hr', name, template_folder='templates')

def hr_only():
    if current_user.role not in ('hr','admin'):
        flash('Недостаточно прав','danger')
        return False
    return True

@hr_bp.route('/skills', methods=['GET'])
@login_required
def skills():
    if not hr_only(): return redirect(url_for('main.dashboard'))
    skills = Skill.query.order_by(Skill.category, Skill.name).all()
    form = SkillForm()
    return render_template('hr/skills.html', skills=skills, form=form)

@hr_bp.route('/skills/add', methods=['POST'])
@login_required
def add_skill():
    if not hr_only(): return redirect(url_for('main.dashboard'))
    form = SkillForm()
    if form.validate_on_submit():
        s = Skill(name=form.name.data, category=form.category.data, description=form.description.data)
        db.session.add(s)
        db.session.commit()
        flash('Навык добавлен','success')
    else:
        flash('Ошибка формы','danger')
    return redirect(url_for('hr.skills'))

@hr_bp.route('/users', methods=['GET','POST'])
@login_required
def users():
    if not hr_only(): return redirect(url_for('main.dashboard'))
    form = UserCreateForm()
    departments = Department.query.order_by(Department.name).all()
    if form.validate_on_submit():
        pwd = 'password'
        u = User(login=form.login.data, full_name=form.full_name.data, email=form.email.data,
                 role=form.role.data, department_id=form.department_id.data or None,
                 password_hash=generate_password_hash(pwd))
        db.session.add(u)
        db.session.commit()
        flash(f'Пользователь создан (пароль: {pwd})','success')
        return redirect(url_for('hr.users'))
    users = User.query.order_by(User.full_name).all()
    return render_template('hr/users.html', users=users, form=form, departments=departments)

@hr_bp.route('/departments', methods=['GET'])
@login_required
def departments():
    if not hr_only(): return redirect(url_for('main.dashboard'))
    deps = Department.query.order_by(Department.name).all()
    return render_template('hr/departments.html', departments=deps)
