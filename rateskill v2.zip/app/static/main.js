// small helper
console.log("SkillTracker frontend loaded");
