---

# 6) seed_data.py — создаёт БД и тестовые данные (использует db.create_all)
```python
# seed_data.py
from app import create_app, db
from app.models import User, Department, Skill, SkillAssessment
from werkzeug.security import generate_password_hash

app = create_app()

with app.app_context():
    print("Dropping and creating tables (development)...")
    db.drop_all()
    db.create_all()

    # Departments
    eng = Department(name='Engineering')
    hr = Department(name='HR')
    db.session.add_all([eng, hr])
    db.session.commit()

    # Users
    u1 = User(login='alice', password_hash=generate_password_hash('password'), role='employee', full_name='Alice Example', department=eng)
    u2 = User(login='bob', password_hash=generate_password_hash('password'), role='manager', full_name='Bob Manager', department=eng)
    u3 = User(login='carol', password_hash=generate_password_hash('password'), role='hr', full_name='Carol HR', department=hr)
    db.session.add_all([u1, u2, u3])
    db.session.commit()

    eng.manager_id = u2.id
    db.session.commit()

    # Skills
    s1 = Skill(name='Python', category='Programming', description='Python language')
    s2 = Skill(name='Flask', category='Framework', description='Flask microframework')
    s3 = Skill(name='Communication', category='Soft', description='Soft skill')
    s4 = Skill(name='Docker', category='DevOps', description='Containers')
    s5 = Skill(name='React', category='Frontend', description='React.js framework')
    db.session.add_all([s1, s2, s3, s4, s5])
    db.session.commit()

    # Assessments for Alice
    a1 = SkillAssessment(user=u1, skill=s1, self_score=4)
    a2 = SkillAssessment(user=u1, skill=s2, self_score=3)
    a3 = SkillAssessment(user=u1, skill=s3, self_score=5)
    db.session.add_all([a1, a2, a3])
    db.session.commit()

    print("Seed data created. Users: alice/password, bob/password, carol/password")
