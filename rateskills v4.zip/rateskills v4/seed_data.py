from app import create_app, db
from werkzeug.security import generate_password_hash
from app.models import User, Department, Skill

app = create_app()

with app.app_context():
    db.drop_all()
    db.create_all()

    d1 = Department(name="Backend")
    d2 = Department(name="Frontend")
    db.session.add_all([d1, d2])

    admin = User(
        login="admin",
        password_hash=generate_password_hash("admin"),
        role="admin",
        full_name="HR Admin",
        department=d1
    )

    manager = User(
        login="manager",
        password_hash=generate_password_hash("manager"),
        role="manager",
        full_name="Team Lead",
        department=d1
    )

    emp = User(
        login="employee",
        password_hash=generate_password_hash("employee"),
        role="employee",
        full_name="Employee A",
        department=d1
    )

    db.session.add_all([admin, manager, emp])

    skills = [
        Skill(name="Python", category="Programming"),
        Skill(name="Flask", category="Frameworks"),
        Skill(name="Teamwork", category="Soft Skills")
    ]

    db.session.add_all(skills)
    db.session.commit()

    print("Database seeded successfully!")
