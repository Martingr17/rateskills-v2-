#!/bin/bash
flask db upgrade
python seed_data.py
gunicorn -w 4 -b 0.0.0.0:5000 wsgi:app
