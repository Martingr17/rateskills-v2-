from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app.utils import role_required
from app.models import Skill, SkillAssessment, AssessmentHistory
from app import db

employee_bp = Blueprint("employee", __name__)


@employee_bp.route("/employee/skills")
@login_required
@role_required("employee")
def list_skills():
    skills = Skill.query.order_by(Skill.category, Skill.name).all()

    data = {}
    for s in skills:
        data.setdefault(s.category, []).append(s)

    return render_template("employee/skills.html", skills=data)


@employee_bp.route("/employee/set_score", methods=["POST"])
@login_required
@role_required("employee")
def set_score():
    skill_id = request.json["skill_id"]
    score = request.json["score"]

    assessment = SkillAssessment.query.filter_by(
        user_id=current_user.id,
        skill_id=skill_id
    ).first()

    if not assessment:
        assessment = SkillAssessment(
            user_id=current_user.id,
            skill_id=skill_id,
            self_score=score
        )
        db.session.add(assessment)
    else:
        old = assessment.self_score
        assessment.self_score = score

        hist = AssessmentHistory(
            assessment=assessment,
            old_score=old,
            new_score=score,
            changed_by=current_user.id
        )
        db.session.add(hist)

    db.session.commit()
    return jsonify({"success": True})
