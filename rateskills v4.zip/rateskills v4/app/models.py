from datetime import datetime
from app import db, login_manager
from flask_login import UserMixin


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class Department(db.Model):
    __tablename__ = "departments"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    users = db.relationship("User", back_populates="department")


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    role = db.Column(db.String(20), nullable=False)
    full_name = db.Column(db.String(150), nullable=False)

    department_id = db.Column(db.Integer, db.ForeignKey("departments.id"))
    department = db.relationship("Department", back_populates="users")

    assessments = db.relationship("SkillAssessment", back_populates="user")


class Skill(db.Model):
    __tablename__ = "skills"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, default="")

    assessments = db.relationship("SkillAssessment", back_populates="skill")


class SkillAssessment(db.Model):
    __tablename__ = "skill_assessments"

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    skill_id = db.Column(db.Integer, db.ForeignKey("skills.id"), nullable=False)

    self_score = db.Column(db.Integer)
    manager_score = db.Column(db.Integer)

    assessed_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", back_populates="assessments")
    skill = db.relationship("Skill", back_populates="assessments")

    history = db.relationship("AssessmentHistory", back_populates="assessment")


class AssessmentHistory(db.Model):
    __tablename__ = "assessment_history"

    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("skill_assessments.id"))

    old_score = db.Column(db.Integer)
    new_score = db.Column(db.Integer)
    changed_by = db.Column(db.Integer, db.ForeignKey("users.id"))

    changed_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessment = db.relationship("SkillAssessment", back_populates="history")
