// static/js/app.js
(()=> {
  const api = {
    skills: '/api/skills',                // GET -> [{id,name,category,description,created_at}]
    my_assessments: '/api/my_assessments',// GET -> [{skill_id, self_score, manager_score, updated_at}]
    assess: '/api/assess',                // POST {skill_id, score} -> 200/JSON
    required_skills: '/api/required_skills', // GET -> [{skill_id, name}]
    mini_profile: '/api/mini_profile',    // GET -> {labels:[], values:[], updated_at}
    profile_history: id => `/api/profile/${id}/history`, // GET -> [{field, old_score, new_score, changed_by, changed_at}]
    employees: '/api/employees',          // GET -> list of users + dept + key skills
    user_profile: id => `/api/users/${id}`,
    compare: '/api/compare',              // POST {user_ids:[]} -> {labels:[], datasets:[]}
    csv_export: '/api/export',            // GET -> attachment
    hr_skills_actions: '/api/hr/skills'   // POST/PUT/DELETE -> manage skills
  };

  // utilities
  function el(tag, cls) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    return e;
  }

  function qs(sel, ctx=document) { return ctx.querySelector(sel); }
  function qsa(sel, ctx=document) { return Array.from(ctx.querySelectorAll(sel)); }
  function showError(msg) { console && console.error(msg); }

  // fetch wrapper
  async function fetchJson(url, opts={}) {
    const res = await fetch(url, Object.assign({credentials: 'same-origin', headers: {'Content-Type':'application/json'}}, opts));
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
    // try parse json safely
    const text = await res.text();
    if (!text) return null;
    try { return JSON.parse(text); } catch(e) { return text; }
  }

  // ========== DASHBOARD ==========

  async function loadSkillsList() {
    const container = qs('#skills-list');
    try {
      const skills = await fetchJson(api.skills);
      const myAssess = await fetchJson(api.my_assessments);
      const myMap = {};
      (myAssess||[]).forEach(a => myMap[a.skill_id] = a);

      // group by category
      const groups = {};
      (skills||[]).forEach(s => {
        const cat = s.category || 'Прочее';
        groups[cat] = groups[cat] || [];
        groups[cat].push(s);
      });

      container.innerHTML = '';
      for (const cat of Object.keys(groups).sort()) {
        const catDiv = el('div', 'category mb-3');
        const h = el('h6');
        h.textContent = cat;
        catDiv.appendChild(h);

        groups[cat].forEach(skill => {
          const row = el('div','skill-row');
          const left = el('div','d-flex align-items-center gap-3');
          const name = el('div','skill-name');
          name.textContent = skill.name;
          const desc = el('div','small text-muted');
          desc.textContent = skill.description || '';
          left.appendChild(name);
          left.appendChild(desc);

          const right = el('div','d-flex align-items-center gap-2');
          // show current user's self score as badge if exists
          const as = myMap[skill.id];
          const scoreBadge = el('span','badge bg-light text-dark');
          if (as && as.self_score) scoreBadge.textContent = `Вы: ${as.self_score}`;
          else scoreBadge.textContent = 'Не оценен';
          right.appendChild(scoreBadge);

          const btn = el('button','btn btn-sm btn-outline-primary');
          btn.textContent = 'Оценить';
          btn.onclick = () => openRatingModal(skill, as);
          right.appendChild(btn);

          row.appendChild(left);
          row.appendChild(right);
          catDiv.appendChild(row);
        });

        container.appendChild(catDiv);
      }
    } catch (e) {
      container.innerHTML = `<div class="text-danger">Ошибка загрузки навыков: ${e.message}</div>`;
      showError(e);
    }
  }

  function openRatingModal(skill, assessment) {
    const modalEl = qs('#ratingModal');
    const nameEl = qs('#ratingSkillName');
    const btns = qs('#ratingButtons');
    const note = qs('#ratingNote');
    nameEl.textContent = skill.name;
    note.textContent = assessment && assessment.manager_score ? `Последняя оценка менеджера: ${assessment.manager_score}` : '';
    btns.innerHTML = '';
    for (let i=1;i<=5;i++) {
      const b = el('button','btn btn-outline-secondary');
      b.textContent = i;
      b.onclick = async () => {
        try {
          b.disabled = true;
          await fetchJson(api.assess, {method:'POST', body: JSON.stringify({skill_id: skill.id, score: i})});
          // success: close modal and refresh list and mini-radar
          const mb = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
          mb.hide();
          await loadSkillsList();
          await loadMiniProfile();
        } catch(err) {
          alert('Ошибка отправки оценки: ' + err.message);
        } finally { b.disabled = false; }
      };
      btns.appendChild(b);
    }
    const mb = new bootstrap.Modal(modalEl);
    mb.show();
  }

  async function loadRequiredSkills() {
    try {
      const list = qs('#required-skills');
      const required = await fetchJson(api.required_skills) || [];
      list.innerHTML = '';
      if (!required.length) {
        list.innerHTML = '<li class="list-group-item text-muted">Нет обязательных навыков</li>';
      } else {
        required.forEach(s=>{
          const li = el('li','list-group-item');
          li.textContent = s.name;
          list.appendChild(li);
        });
      }
    } catch(e) { showError(e); }
  }

  // Mini radar chart
  let miniRadarChart = null;
  async function loadMiniProfile() {
    try {
      const data = await fetchJson(api.mini_profile);
      if (!data || !data.labels) return;
      const ctx = qs('#mini-radar').getContext('2d');
      if (miniRadarChart) miniRadarChart.destroy();
      miniRadarChart = new Chart(ctx, {
        type: 'radar',
        data: {
          labels: data.labels,
          datasets: [{
            label: 'Профиль',
            data: data.values,
            fill: true,
            tension: 0.1,
          }]
        },
        options: {
          scales: {
            r: { min: 0, max: 5, ticks: { stepSize: 1 } }
          },
          plugins: { legend: { display: false } }
        }
      });
    } catch(e) { showError(e); }
  }

  // ========== PROFILE PAGE ==========
  async function loadProfile(userId) {
    try {
      const p = await fetchJson(`/api/users/${userId}/profile`);
      // p should contain labels[], values[], updated_at, history[]
      const ctx = qs('#radarChart').getContext('2d');
      const data = { labels: p.labels, datasets: [{ label: p.name || 'Профиль', data: p.values, fill:true }] };
      window.profileRadar && window.profileRadar.destroy();
      window.profileRadar = new Chart(ctx, { type:'radar', data, options:{scales:{r:{min:0,max:5}}} });
      qs('#profile-updated').textContent = p.updated_at || '—';

      // history
      const histArea = qs('#history-list');
      histArea.innerHTML = '';
      if (!p.history || !p.history.length) histArea.innerHTML = '<div class="text-muted">История отсутствует</div>';
      else {
        p.history.forEach(h=>{
          const card = el('div','mb-2');
          card.innerHTML = `<div class="d-flex justify-content-between"><div><strong>${h.skill_name}</strong><div class="small text-muted">${h.field}</div></div><div class="text-end">${h.old_score} → ${h.new_score}<div class="small text-muted">${h.changed_at}</div></div></div>`;
          histArea.appendChild(card);
        });
      }
    } catch(e) { showError(e); }
  }

  // ========== EMPLOYEES / FILTERS / COMPARE ==========
  function makeFilterRow() {
    const wrapper = el('div','d-flex gap-2 mb-2 filter-row');
    const skillInput = el('input','form-control form-control-sm skill-input');
    skillInput.placeholder = 'Навык (начните вводить)';
    const opSelect = el('select','form-select form-select-sm');
    opSelect.innerHTML = '<option value="gte">≥</option><option value="lte">≤</option><option value="eq">=</option>';
    const scoreInput = el('input','form-control form-control-sm score-input');
    scoreInput.type = 'number'; scoreInput.min=1; scoreInput.max=5; scoreInput.placeholder = 'оценка';
    const remove = el('button','btn btn-sm btn-outline-danger');
    remove.textContent = 'Удалить';
    remove.onclick = ()=> wrapper.remove();
    wrapper.append(skillInput, opSelect, scoreInput, remove);
    return wrapper;
  }

  async function loadEmployees() {
    try {
      const area = qs('#employees-list');
      const data = await fetchJson(api.employees) || [];
      area.innerHTML = '';
      if (!data.length) { area.innerHTML = '<div class="text-muted">Сотрудников не найдено</div>'; return; }
      data.forEach(u=>{
        const item = el('div','d-flex align-items-center justify-content-between mb-2 p-2 bg-white rounded');
        const left = el('div');
        left.innerHTML = `<div class="fw-semibold">${u.full_name || u.login}</div><div class="small text-muted">${u.role} — ${u.department_name || ''}</div>`;
        const right = el('div','d-flex gap-2 align-items-center');
        const cb = el('input'); cb.type = 'checkbox'; cb.className = 'form-check-input compare-checkbox'; cb.dataset.userId = u.id;
        const view = el('a','btn btn-sm btn-outline-primary'); view.href = `/profile/${u.id}`; view.textContent = 'Профиль';
        const compareBtn = el('button','btn btn-sm btn-outline-secondary'); compareBtn.textContent = 'Сравнить'; compareBtn.onclick = ()=>{
          cb.checked = !cb.checked; updateCompareButtons();
        };
        right.append(cb, view, compareBtn);
        item.append(left,right);
        area.appendChild(item);
      });
    } catch(e) { showError(e); }
  }

  function updateCompareButtons() {
    const checked = qsa('.compare-checkbox:checked').map(i => parseInt(i.dataset.userId));
    qs('#do-compare').disabled = checked.length < 2;
  }

  async function doCompare() {
    const checked = qsa('.compare-checkbox:checked').map(i => parseInt(i.dataset.userId));
    if (checked.length < 2) return alert('Выберите хотя бы 2 сотрудника');
    try {
      const res = await fetchJson(api.compare, {method:'POST', body: JSON.stringify({user_ids: checked})});
      // render radar datasets (res.labels, res.datasets)
      const ctx = qs('#compareRadar').getContext('2d');
      window.compareChart && window.compareChart.destroy();
      window.compareChart = new Chart(ctx, { type:'radar', data: { labels: res.labels, datasets: res.datasets }, options:{scales:{r:{min:0,max:5}}} });
      // table
      const tableWrap = qs('#compare-table');
      const header = `<tr><th>Навык</th>${res.datasets.map(d=>`<th>${d.label}</th>`).join('')}</tr>`;
      const rows = res.labels.map((lab, idx) => `<tr><td>${lab}</td>${res.datasets.map(d=>`<td>${d.data[idx]===null ? '—' : d.data[idx]}</td>`).join('')}</tr>`).join('');
      tableWrap.innerHTML = `<table class="table table-sm table-bordered"><thead>${header}</thead><tbody>${rows}</tbody></table>`;
    } catch(e) { alert('Ошибка сравнения: '+e.message); showError(e); }
  }

  // ========== INIT depending on page ==========
  function initPage() {
    const page = window.RS_PAGE;
    if (page === 'dashboard') {
      loadSkillsList();
      loadRequiredSkills();
      loadMiniProfile();
      // search
      const s = qs('#skill-search');
      s && s.addEventListener('input', (ev)=>{
        const q = ev.target.value.toLowerCase();
        qsa('.skill-row').forEach(r=>{
          const name = r.querySelector('.skill-name').textContent.toLowerCase();
          r.style.display = name.includes(q) ? '' : 'none';
        });
      });
    } else if (page === 'profile') {
      const userId = window.RS_USER_ID;
      if (userId) loadProfile(userId);
    } else if (page === 'employees') {
      loadEmployees();
      qs('#add-filter') && qs('#add-filter').addEventListener('click', ()=> { qs('#filters-area').appendChild(makeFilterRow()); });
      // compare
      document.addEventListener('change', (e)=>{ if (e.target.classList && e.target.classList.contains('compare-checkbox')) updateCompareButtons(); });
      qs('#do-compare') && qs('#do-compare').addEventListener('click', doCompare);
    } else if (page === 'skills_admin') {
      // TODO: admin skill management; backend integration to load list and handle create/update/delete
      loadAdminSkills();
      qs('#add-category-form') && qs('#add-category-form').addEventListener('submit', async (e)=>{
        e.preventDefault();
        const name = e.target.name.value.trim();
        if (!name) return alert('Укажите название');
        try {
          await fetchJson(api.hr_skills_actions, {method:'POST', body: JSON.stringify({action:'add_category', name})});
          alert('Категория добавлена'); loadAdminSkills();
        } catch(err){ alert('Ошибка: '+err.message); }
      });
    } else if (page === 'compare') {
      // populate selection with employees
      (async ()=> {
        const users = await fetchJson(api.employees);
        const elsel = qs('#compare-select');
        elsel.innerHTML = '';
        (users||[]).forEach(u => {
          const o = document.createElement('option');
          o.value = u.id; o.textContent = `${u.full_name || u.login} (${u.department_name || ''})`;
          elsel.appendChild(o);
        });
        qs('#render-compare').addEventListener('click', async ()=> {
          const selected = Array.from(elsel.selectedOptions).map(o=>parseInt(o.value));
          if (!selected.length) return alert('Выберите сотрудников');
          // reuse compare endpoint
          try {
            const res = await fetchJson(api.compare, {method:'POST', body: JSON.stringify({user_ids: selected})});
            // same rendering as doCompare
            const ctx = qs('#compareRadar').getContext('2d');
            window.compareChart && window.compareChart.destroy();
            window.compareChart = new Chart(ctx, { type:'radar', data: { labels: res.labels, datasets: res.datasets }, options:{scales:{r:{min:0,max:5}}} });
            // table
            const tableWrap = qs('#compare-table');
            const header = `<tr><th>Навык</th>${res.datasets.map(d=>`<th>${d.label}</th>`).join('')}</tr>`;
            const rows = res.labels.map((lab, idx) => `<tr><td>${lab}</td>${res.datasets.map(d=>`<td>${d.data[idx]===null ? '—' : d.data[idx]}</td>`).join('')}</tr>`).join('');
            tableWrap.innerHTML = `<table class="table table-sm table-bordered"><thead>${header}</thead><tbody>${rows}</tbody></table>`;
          } catch(err){ alert('Ошибка: '+err.message); }
        });
      })();
    }
  }

  // admin skill list loader (simple)
  async function loadAdminSkills() {
    try {
      const container = qs('#skills-admin-list');
      const skills = await fetchJson(api.skills);
      container.innerHTML = '';
      if (!skills || !skills.length) { container.innerHTML = '<div class="text-muted">Нет навыков</div>'; return; }
      skills.forEach(s=>{
        const row = el('div','d-flex align-items-center justify-content-between mb-2 p-2 bg-white rounded');
        row.innerHTML = `<div><strong>${s.name}</strong> <div class="small text-muted">${s.category||''}</div></div>`;
        const right = el('div','d-flex gap-2');
        const edit = el('button','btn btn-sm btn-outline-secondary'); edit.textContent='Ред.';
        const del = el('button','btn btn-sm btn-outline-danger'); del.textContent='Удал.';
        // wiring to backend operations is left to backend endpoints
        edit.onclick = ()=> alert('Редактирование — через backend (реализовать API)');
        del.onclick = ()=> {
          if (!confirm(`Удалить навык "${s.name}"?`)) return;
          fetchJson(api.hr_skills_actions, {method:'DELETE', body: JSON.stringify({id: s.id})})
            .then(()=> loadAdminSkills()).catch(err=> alert('Ошибка: '+err.message));
        };
        right.append(edit,del);
        row.appendChild(right);
        container.appendChild(row);
      });
    } catch(e) { showError(e); }
  }

  // initialize
  document.addEventListener('DOMContentLoaded', initPage);
})();
