from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app.utils import role_required
from app.models import User, SkillAssessment, AssessmentHistory, Skill
from app import db

manager_bp = Blueprint("manager", __name__)


@manager_bp.route("/manager/employees")
@login_required
@role_required("manager")
def employees():
    emps = User.query.filter_by(department_id=current_user.department_id).all()
    return render_template("manager/employees.html", employees=emps)


@manager_bp.route("/manager/profile/<int:user_id>")
@login_required
@role_required("manager")
def employee_profile(user_id):
    user = User.query.get_or_404(user_id)
    assessments = SkillAssessment.query.filter_by(user_id=user.id).all()
    return render_template("manager/profile.html", user=user, assessments=assessments)


@manager_bp.route("/manager/set_score", methods=["POST"])
@login_required
@role_required("manager")
def set_score():
    assessment_id = request.json["assessment_id"]
    new_score = request.json["score"]

    a = SkillAssessment.query.get(assessment_id)
    old = a.manager_score

    a.manager_score = new_score

    hist = AssessmentHistory(
        assessment_id=a.id,
        old_score=old,
        new_score=new_score,
        changed_by=current_user.id
    )

    db.session.add(hist)
    db.session.commit()

    return jsonify({"success": True})
