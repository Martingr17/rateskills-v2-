from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_required
from app.utils import role_required
from app.models import Skill
from app import db

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/admin/skills")
@login_required
@role_required("admin")
def skills():
    skills = Skill.query.order_by(Skill.category, Skill.name).all()
    return render_template("admin/skills.html", skills=skills)


@admin_bp.route("/admin/skill/add", methods=["POST"])
@login_required
@role_required("admin")
def add_skill():
    name = request.form["name"]
    category = request.form["category"]

    s = Skill(name=name, category=category)
    db.session.add(s)
    db.session.commit()

    return redirect(url_for("admin.skills"))
