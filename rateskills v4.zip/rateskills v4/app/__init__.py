from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_cors import CORS
import os

db = SQLAlchemy()
login_manager = LoginManager()
migrate = None


def create_app():
    app = Flask(__name__)
    CORS(app)

    app.config.from_object("app.config.Config")

    db.init_app(app)

    global migrate
    migrate = Migrate(app, db)

    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    # регистрация блюпринтов
    from app.routes_auth import auth_bp
    from app.routes_employee import employee_bp
    from app.routes_manager import manager_bp
    from app.routes_admin import admin_bp
    from app.routes_common import common_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(manager_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(common_bp)

    return app
