from flask import Blueprint, render_template
from flask_login import login_required

common_bp = Blueprint("common", __name__)


@common_bp.route("/")
@login_required
def index():
    return render_template("index.html")
