"""
SkillMatrix API Module
"""

from app.api.api_v1 import api_router

__all__ = ["api_router"]