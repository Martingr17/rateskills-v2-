# app/models.py
from . import db, login_manager
from flask_login import UserMixin
from datetime import datetime

class Department(db.Model):
    tablename = 'departments'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False, unique=True)
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id', use_alter=True, name='fk_department_manager'))

    users = db.relationship('User', back_populates='department')

class User(UserMixin, db.Model):
    tablename = 'users'
    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.String(128), nullable=False, unique=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(32), nullable=False)  # 'employee','manager','hr','admin'
    full_name = db.Column(db.String(256))
    email = db.Column(db.String(256))
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    department = db.relationship('Department', back_populates='users')
    assessments = db.relationship('SkillAssessment', back_populates='user', cascade='all, delete-orphan')

    def is_manager_of(self, user):
        return self.role == 'manager' and self.department_id is not None and self.department_id == user.department_id

    def __repr__(self):
        return f'<User {self.login}>'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Skill(db.Model):
    tablename = 'skills'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False, unique=True)
    category = db.Column(db.String(64))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessments = db.relationship('SkillAssessment', back_populates='skill')

class SkillAssessment(db.Model):
    tablename = 'skill_assessments'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    skill_id = db.Column(db.Integer, db.ForeignKey('skills.id'), nullable=False)
    self_score = db.Column(db.Integer)
    manager_score = db.Column(db.Integer)
    assessed_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', back_populates='assessments')
    skill = db.relationship('Skill', back_populates='assessments')
    history = db.relationship('AssessmentHistory', back_populates='assessment', cascade='all, delete-orphan', order_by="desc(AssessmentHistory.changed_at)")

class AssessmentHistory(db.Model):
    tablename = 'assessment_history'
    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey('skill_assessments.id'), nullable=False)
    field = db.Column(db.String(32))  # 'self_score' or 'manager_score'
    old_score = db.Column(db.Integer)
    new_score = db.Column(db.Integer)
    changed_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    changed_at = db.Column(db.DateTime, default=datetime.utcnow)

    assessment = db.relationship('SkillAssessment', back_populates='history')
