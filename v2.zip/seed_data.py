# seed_sql.py - используем только SQL без ORM
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy import create_engine, text, MetaData
from werkzeug.security import generate_password_hash

# Прямое подключение к БД
DATABASE_URI = 'postgresql://postgres:postgres@db:5432/skilldb'
engine = create_engine(DATABASE_URI)

with engine.connect() as conn:
    print("Dropping and creating tables (development)...")
    
    # Удаляем все таблицы
    conn.execute(text('DROP TABLE IF EXISTS skill_assessment CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS skill CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS "user" CASCADE'))
    conn.execute(text('DROP TABLE IF EXISTS department CASCADE'))
    conn.commit()
    
    # Создаем таблицы с foreign keys DEFERRED
    conn.execute(text('''
        CREATE TABLE department (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            manager_id INTEGER
        )
    '''))
    
    conn.execute(text('''
        CREATE TABLE "user" (
            id SERIAL PRIMARY KEY,
            login VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL,
            full_name VARCHAR(100),
            department_id INTEGER
        )
    '''))
    
    conn.execute(text('''
        CREATE TABLE skill (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            category VARCHAR(50),
            description TEXT
        )
    '''))
    
    conn.execute(text('''
        CREATE TABLE skill_assessment (
            id SERIAL PRIMARY KEY,
            user_id INTEGER,
            skill_id INTEGER,
            self_score INTEGER CHECK (self_score >= 1 AND self_score <= 5),
            manager_score INTEGER CHECK (manager_score >= 1 AND manager_score <= 5),
            UNIQUE(user_id, skill_id)
        )
    '''))
    
    conn.commit()
    
    print("Tables created successfully!")
    
    # Вставляем данные через SQL
    # Departments
    conn.execute(text('''
        INSERT INTO department (name) VALUES 
        ('Engineering'), 
        ('HR')
    '''))
    
    # Users с хэшами паролей
    alice_hash = generate_password_hash('password')
    bob_hash = generate_password_hash('password')
    carol_hash = generate_password_hash('password')
    
    conn.execute(text('''
        INSERT INTO "user" (login, password_hash, role, full_name, department_id) VALUES 
        (:alice, :alice_hash, 'employee', 'Alice Example', 1),
        (:bob, :bob_hash, 'manager', 'Bob Manager', 1),
        (:carol, :carol_hash, 'hr', 'Carol HR', 2)
    '''), {
        'alice': 'alice',
        'alice_hash': alice_hash,
        'bob': 'bob', 
        'bob_hash': bob_hash,
        'carol': 'carol',
        'carol_hash': carol_hash
    })
    
    # Обновляем manager_id
    conn.execute(text('''
        UPDATE department SET manager_id = 2 WHERE id = 1
    '''))
    
    # Skills
    conn.execute(text('''
        INSERT INTO skill (name, category, description) VALUES 
        ('Python', 'Programming', 'Python language'),
        ('Flask', 'Framework', 'Flask microframework'),
        ('Communication', 'Soft', 'Soft skill'),
        ('Docker', 'DevOps', 'Containers'),
        ('React', 'Frontend', 'React.js framework')
    '''))
    
    # Assessments for Alice
    conn.execute(text('''
        INSERT INTO skill_assessment (user_id, skill_id, self_score) VALUES 
        (1, 1, 4),
        (1, 2, 3),
        (1, 3, 5)
    '''))
    
    # Теперь добавляем foreign keys
    conn.execute(text('''
        ALTER TABLE "user" 
        ADD CONSTRAINT fk_user_department 
        FOREIGN KEY (department_id) REFERENCES department(id)
    '''))
    
    conn.execute(text('''
        ALTER TABLE department 
        ADD CONSTRAINT fk_department_manager 
        FOREIGN KEY (manager_id) REFERENCES "user"(id)
    '''))
    
    conn.execute(text('''
        ALTER TABLE skill_assessment 
        ADD CONSTRAINT fk_assessment_user 
        FOREIGN KEY (user_id) REFERENCES "user"(id)
    '''))
    
    conn.execute(text('''
        ALTER TABLE skill_assessment 
        ADD CONSTRAINT fk_assessment_skill 
        FOREIGN KEY (skill_id) REFERENCES skill(id)
    '''))
    
    conn.commit()
    
    print("Seed data created. Users: alice/password, bob/password, carol/password")
