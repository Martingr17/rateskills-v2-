from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.orm import Session
import logging
import os
from pathlib import Path
from datetime import datetime
import traceback

from app.database import SessionLocal, engine, Base
from app.config import settings
from app.models import *
from app.api.api_v1 import api_router
from app.utils.seed import seed_database
from app.utils import is_development

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('skillmatrix.log')
    ]
)
logger = logging.getLogger(__name__)

# Create database tables
try:
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created successfully")
except Exception as e:
    logger.error(f"Error creating database tables: {e}")

# Seed database with initial data if needed
if settings.SEED_DATABASE:
    try:
        seed_database()
        logger.info("Database seeded successfully")
    except Exception as e:
        logger.error(f"Error seeding database: {e}")

# Create FastAPI app
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=None,  # Disable default docs
    redoc_url=None,  # Disable default redoc
    description="""
    SkillMatrix PRO API v3.0
    
    ## Features
    
    * **Authentication**: JWT-based auth with roles (employee, manager, admin, hr, director)
    * **Skills Management**: Create, read, update, delete skills and categories
    * **Assessments**: Self-assessments and manager approvals
    * **Reports**: Generate reports and export to CSV/JSON
    * **Dashboard**: Role-based dashboard with statistics
    * **Notifications**: Real-time notifications system
    
    ## Roles & Permissions
    
    1. **Employee**: Can self-assess skills, view own profile and progress
    2. **Manager**: Can manage team assessments, approve/reject, view team stats
    3. **HR**: Can manage users, skills, generate company-wide reports
    4. **Admin**: Full system access including configuration
    5. **Director**: Strategic overview and high-level reports
    
    ## Default Demo Accounts
    
    * **Employee**: user / 123
    * **Manager**: manager / 123  
    * **HR/Admin**: admin / 123
    * **Backend Developer**: dev2 / 123
    * **Designer**: des1 / 123
    * **HR Specialist**: hr1 / 123
    """,
    terms_of_service="https://skillmatrix.example.com/terms/",
    contact={
        "name": "SkillMatrix Support",
        "url": "https://skillmatrix.example.com/support",
        "email": "support@skillmatrix.example.com",
    },
    license_info={
        "name": "Proprietary",
        "url": "https://skillmatrix.example.com/license",
    },
)

# Add middlewares
app.add_middleware(GZipMiddleware, minimum_size=1000)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)

# Static files - serve the frontend HTML file
static_dir = Path(__file__).parent / "static"
static_dir.mkdir(exist_ok=True)

# Copy the provided HTML file to static directory
html_content = """
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkillMatrix Enterprise PRO v3.0</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        /* Your CSS styles here */
        /* Note: In production, this would be served from a separate file */
    </style>
</head>
<body>
    <div id="root"></div>
    <script>
        // Your JavaScript code here
        // Note: In production, this would be served from separate JS files
    </script>
</body>
</html>
"""

# Write HTML file to static directory
html_file = static_dir / "index.html"
html_file.write_text(html_content, encoding="utf-8")

# Mount static files
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# Include API router
app.include_router(api_router)

# Custom exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    logger.warning(f"HTTPException: {exc.status_code} - {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": True,
            "code": exc.status_code,
            "message": exc.detail,
            "path": request.url.path,
            "timestamp": datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle validation errors"""
    logger.warning(f"Validation error: {exc.errors()}")
    return JSONResponse(
        status_code=422,
        content={
            "error": True,
            "code": 422,
            "message": "Validation error",
            "details": exc.errors(),
            "path": request.url.path,
            "timestamp": datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle all other exceptions"""
    logger.error(f"Unhandled exception: {exc}\n{traceback.format_exc()}")
    
    # In production, don't expose internal errors
    if is_development():
        detail = str(exc)
    else:
        detail = "Internal server error"
    
    return JSONResponse(
        status_code=500,
        content={
            "error": True,
            "code": 500,
            "message": detail,
            "path": request.url.path,
            "timestamp": datetime.utcnow().isoformat()
        }
    )

# Custom docs endpoints
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    """Custom Swagger UI"""
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - Swagger UI",
        oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
        swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
        swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
    )

@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    """Custom ReDoc"""
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - ReDoc",
        redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@next/bundles/redoc.standalone.js",
    )

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check for load balancers and monitoring"""
    return {
        "status": "healthy",
        "service": "skillmatrix-backend",
        "version": settings.VERSION,
        "timestamp": datetime.utcnow().isoformat(),
        "database": "connected"  # You could add actual DB check
    }

# Root endpoint - redirect to frontend
@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main frontend application"""
    return FileResponse(static_dir / "index.html")

# API documentation redirect
@app.get("/api")
async def api_docs_redirect():
    """Redirect to API documentation"""
    return RedirectResponse(url="/docs")

# Favicon
@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse(static_dir / "favicon.ico")

# Startup event
@app.on_event("startup")
async def startup_event():
    """Actions to perform on application startup"""
    logger.info(f"Starting {settings.PROJECT_NAME} v{settings.VERSION}")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"Database URL: {settings.DATABASE_URL.split('@')[-1] if '@' in settings.DATABASE_URL else 'Local SQLite'}")
    
    # Create uploads directory if it doesn't exist
    uploads_dir = Path("uploads")
    uploads_dir.mkdir(exist_ok=True)
    
    # Create reports directory
    reports_dir = Path("reports")
    reports_dir.mkdir(exist_ok=True)

# Shutdown event  
@app.on_event("shutdown")
async def shutdown_event():
    """Actions to perform on application shutdown"""
    logger.info("Shutting down SkillMatrix backend")

# Simple database test endpoint
@app.get("/test-db")
async def test_database(db: Session = Depends(SessionLocal)):
    """Test database connection"""
    try:
        # Try to execute a simple query
        result = db.execute("SELECT 1").fetchone()
        return {
            "status": "success",
            "database": "connected",
            "test_query": result[0] if result else None
        }
    except Exception as e:
        logger.error(f"Database test failed: {e}")
        raise HTTPException(status_code=500, detail="Database connection failed")

# Version endpoint
@app.get("/version")
async def get_version():
    """Get application version information"""
    return {
        "name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "api_version": "v1",
        "build_date": settings.BUILD_DATE,
        "documentation": "/docs"
    }

# System info endpoint (admin only)
@app.get("/system/info")
async def system_info():
    """Get system information"""
    import platform
    import sys
    import psutil
    
    return {
        "system": {
            "platform": platform.platform(),
            "python_version": sys.version,
            "hostname": platform.node(),
            "processor": platform.processor(),
        },
        "memory": {
            "total": psutil.virtual_memory().total,
            "available": psutil.virtual_memory().available,
            "percent": psutil.virtual_memory().percent,
        },
        "disk": {
            "total": psutil.disk_usage('/').total,
            "used": psutil.disk_usage('/').used,
            "free": psutil.disk_usage('/').free,
            "percent": psutil.disk_usage('/').percent,
        },
        "application": {
            "name": settings.PROJECT_NAME,
            "version": settings.VERSION,
            "environment": settings.ENVIRONMENT,
            "debug": settings.DEBUG,
            "timezone": settings.TIMEZONE,
        }
    }

# Catch-all route for frontend routing (must be last)
@app.get("/{full_path:path}")
async def catch_all(full_path: str):
    """Catch-all route for frontend routing (SPA support)"""
    # Check if the path is an API route
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="API endpoint not found")
    
    # Check if file exists in static directory
    static_file = static_dir / full_path
    if static_file.is_file():
        return FileResponse(static_file)
    
    # Otherwise serve the main index.html for SPA routing
    return FileResponse(static_dir / "index.html")